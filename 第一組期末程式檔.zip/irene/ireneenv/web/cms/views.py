from django.shortcuts import render_to_response
# Create your views here.
from .models import Classification, News

def index(request):
	classification = Classification.objects.all()
	return render_to_response('cms/Ni,hao-Formosa.html',locals())