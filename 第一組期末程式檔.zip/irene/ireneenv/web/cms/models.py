from django.db import models

# Create your models here.
class Classification(models.Model):
	name = models.CharField(max_length=20)
	briefintro = models.CharField(max_length=1000, blank=True)

	def __str__(self):
		return self.name

class News(models.Model):
	topic = models.CharField(max_length=100)
	time = models.CharField(max_length=20, blank=True)
	content = models.CharField(max_length=10000, blank=True)
	classification = models.ForeignKey('Classification',on_delete=models.CASCADE)

	def __str__(self):
		return self.topic