from django.contrib import admin
from .models import Classification,News

# Register your models here.

class ClassificationAdmin(admin.ModelAdmin):
	list_display = ('name', 'briefintro')

class NewsAdmin(admin.ModelAdmin):
	list_display = ('topic', 'time', 'content')

admin.site.register(News)
admin.site.register(Classification)